Covid Stats API
Get all covid related statistics

An api to show covid related data for each country and by each WHO region.

** Endpoints **

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/countries
Countries

this method will return a list of all the countries for which data is available

    ** Params: ** None
    ** Returns: **
        (set) - set containing all the unique country names

Example:

[http://127.0.0.1:5000/api/v1/countries]

Response:

{
    "status": "success",
    "countries": [
        "Côte d’Ivoire",
        "Romania",
        "Türkiye",
        .
        .
        .
        "New Zealand"
    ]
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/regions
Whos

this method will return a list of all the WHO regions for which data is available

    ** Params: ** None
    ** Returns: **
        (set) - set containing all the unique WHO region names

Example:

[http://127.0.0.1:5000/api/v1/regions]

Response:

{
    "status": "success",
    "whos": [
        "EURO",
        "AFRO",
        "AMRO",
        "WPRO",
        "Other",
        "SEARO",
        "EMRO"
    ]
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/deaths
Deathstats

This method will return the death count. The death count can be filtered by country and/or year and also by who region and/or year

    ** Params: **
        country (str): country name
        region (str): who region name
        year (int): 4 digit year
    ** Returns: **
        (int): the total or specific death count based on filters

Example 1:

[http://127.0.0.1:5000/api/v1/deaths]

Response 1:

{
    "status": "success",
    "deaths": {
        "All countries": 5158501455
    },
    "params": {
        "country": null,
        "region": null,
        "year": null
    }
}

Example 2:

[http://127.0.0.1:5000/api/v1/deaths?country=India&year=2020]

Response 2:

{
    "status": "success",
    "deaths": {
        "India": 17022321
    },
    "params": {
        "country": "India",
        "region": null,
        "year": 2020
    }
}

Example 3:

[http://127.0.0.1:5000/api/v1/deaths?region=EMROO&year=2020]

Response 3:

{
    "status": "error",
    "message": "given region is invalid"
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/cases
Casestats

This method will return the case count. The case count can be filtered by country and/or year and also by who region and/or year

    ** Params: **
        country (str): country name
        region (str): who region name
        year (int): 4 digit year
    ** Returns: **
        (int): the total or specific case count based on filters

Example 1:

[http://127.0.0.1:5000/api/v1/cases]

Response 1:

{
    "status": "success",
    "cases": {
        "All countries": 401318665923
    },
    "params": {
        "country": null,
        "region": null,
        "year": null
    }
}

Example 2:

[http://127.0.0.1:5000/api/v1/cases?country=India&year=2020]

Response 2:

{
    "status": "success",
    "cases": {
        "India": 1074019421
    },
    "params": {
        "country": "India",
        "region": null,
        "year": 2020
    }
}

Example 3:

[http://127.0.0.1:5000/api/v1/cases?region=EMROO&year=2020]

Response 3:

{
    "status": "error",
    "message": "given region is invalid"
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/max-deaths
Maxdeaths

This method will return the country with maximum deaths out of all countries we can filter by dates as lower and upper bounds

    ** Params: **
        min_date (str): the minimum date for filtering
        max_date (str): the maximum date for filtering
    ** Returns: **
        (int) - max deaths in a country out of all countries filtered by given range

Example 1:

[http://127.0.0.1:5000/api/v1/max-deaths]

Response 1:

{
    "status": "success",
    "United States of America": 827394185,
    "params": [
        null
    ]
}

Example 2:

[http://127.0.0.1:5000/api/v1/max-deaths?min_date=2021-01-01&max_date=2021-12-31]

Response 2:

{
    "status": "success",
    "United States of America": 223942585,
    "params": [
        "2021-01-01",
        "2021-12-31"
    ]
}

Example 3:

[http://127.0.0.1:5000/api/v1/max-deaths?min_date=2021-01-01&max_date=2020-12-31]

Response 3:

{
    "status": "error",
    "message": "min_date must be smaller than max_date"
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/min-deaths
Mindeaths

This method will return the country with minimum deaths out of all countries we can filter by dates as lower and upper bounds

    ** Params: **
        min_date (str): the minimum date for filtering
        max_date (str): the maximum date for filtering
    ** Returns: **
        (int) - min deaths in a country out of all countries filtered by given range

Example 1:

[http://127.0.0.1:5000/api/v1/min-deaths]

Response 1:

{
    "status": "success",
    "Democratic People's Republic of Korea": 0,
    "params": [
        null
    ]
}

Example 2:

[http://127.0.0.1:5000/api/v1/min-deaths?min_date=2021-01-01&max_date=2021-12-31]

Response 2:

{
    "status": "success",
    "American Samoa": 0,
    "params": [
        "2021-01-01",
        "2021-12-31"
    ]
}

Example 3:

[http://127.0.0.1:5000/api/v1/min-deaths?min_date=2021-01-01&max_date=2020-12-31]

Response 3:

{
    "status": "error",
    "message": "min_date must be smaller than max_date"
}

------------------------------------------------------------------------------------------------------------------------------

GET
/api/v1/avg-deaths
Avgdeaths

this method will return the average deaths combined in all countries

    ** Params: ** None
    ** Returns: **
        (float): the average deaths across all countries

Example

[http://127.0.0.1:5000/api/v1/avg-deaths]

Response

{
    "status": "success",
    "average deaths": 21765828.924050633
}

------------------------------------------------------------------------------------------------------------------------------